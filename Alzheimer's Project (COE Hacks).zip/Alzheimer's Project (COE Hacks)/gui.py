#The purpose of this project is to provide a GUI interface for a facial recognition AI, which will help 
#someone struggling with Alzheimer's remember important information regarding people in their lives.

#Tack on functions manually
from tkinter import Button, Tk, Label, PhotoImage, Toplevel, Canvas, Image, messagebox
from tkinter.filedialog import askopenfilename
from PIL import Image, ImageTk


#Sets up the window
root = Tk()
root.title("The Ultimate Reminder")
root.geometry('350x100')

#Sets up the label text
lbl = Label(root, text="Hello!")
lbl.grid(padx=150, pady=10, row=0, column=0)


#Allows the user to upload an image
def print_path():
    f = askopenfilename(
        parent=root, initialdir='C:/Tutorial',
        title='Choose file',
        filetypes=[('png images', '.png'),
                   ('gif images', '.gif'),
                   ("jpeg files","*.jpg")]
        )
    

    new_window = Toplevel(root)
    new_window.geometry('650x1000')

    image = PhotoImage(file=f)
    l1 = Label(new_window, image=image)
    l1.image = image
    l1.grid(column=0, row=0, padx = 25)

    #You will have to change the line below to run this on different computers; simply adjust the path to where default.png is.
    #Note: default.png is simply a test image; the real program would display a more relevant image.
    image2 = ImageTk.PhotoImage(Image.open("C:\\Users\\jdm23\\Desktop\\Python\\Alzheimer's Project (COE Hacks)\\default.png"))
    l2 = Label(new_window, image=image2)
    l2.image2 = image2
    l2.grid(column=1, row=0, padx = 25)

    #Sets up buttons below images

    def clicked():

        messagebox.showinfo('More Details', 'Additional Information')

    btn = Button(new_window, text="More Details", font=("Arial",20), bg='blue', command=clicked)
    btn.grid(column=2, row=0, pady = 20, padx=(60,0), ipadx=20, ipady=20)

    def clicked2():

        messagebox.showinfo('Calling...', 'Calling John Doe at 1-800-112-2333')
 
    btn = Button(new_window, text="Need Help?", font=("Arial",20), bg='red', command=clicked2)
    btn.grid(column=2, row=1, pady = 5   , padx=(60,0), ipadx=20, ipady=20)

    name = Label(new_window, text="Jack Moran", font=("Arial Bold",30))
    name.grid(column=0, row = 1, sticky="W", padx=(60, 0))

    relation = Label(new_window, text="Grandson", font=("Arial italic",20))
    relation.grid(column=0, row = 2, sticky="W", padx=(60, 0))

    likes = Label(new_window, text="Likes: Video Games, Gym, Coding", font=("Arial", 15)  )
    likes.grid(column=0, row=3, sticky="W", padx=(60,0))
    job = Label(new_window, text="Occupation: Unemployed", font=("Arial", 15))
    job.grid(column=0, row =4, sticky="W", padx=(60,0))

b1 = Button(root, text='Print path', command=print_path)
b1.grid(row=1, column=0, padx=150, pady=10)

root.mainloop()